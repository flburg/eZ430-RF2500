This message announces the release of freeWrap version 6.51. FreeWrap 6.51 is based on TCL/TK 8.5.9

freeWrap is a program that allows creation of stand-alone TCL/TK executables without needing a compiler.

Versions are free and available for the Windows, Linux and Solaris10 (Sparc) operating systems.

Instructions and source code for building freeWrap are also available.

The following additional variations of freeWrap are also available for download:

     freewrapTCLSH       a console-only application which includes only TCL.
     freewrapPLUS        a windowing application that includes TCL/TK along with the following extensions:
                            BLT 2.5
                            SQLite 3.7.4
                            tkpng 0.9
                            TkTable 2.10


Please visit the freeWrap home page:

          http://freewrap.sourceforge.net


Changes implemented in version 6.51
-----------------------------------
   1. This is a bug fix distribution to correct an incompatibility between two components used internally by freeWrap (the Info-Zip code and the zlib library). Version 6.51 fixes a bug which caused an error condition if the ::freewrap::makeZIP command was used more than once. This problem was seen most frequently by people attempting to wrap an application containing more than 50 files (e.g., when wrapping BWidgets) since freeWrap uses ::freewrap::makeZIP to process files in batches of 50 when wrapping.
